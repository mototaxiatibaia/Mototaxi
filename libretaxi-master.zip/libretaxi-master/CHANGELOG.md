*   Add tests to ensure submitted translations have the same number of format tags.

    Fixes #679.

    *Roman Pushkin*
